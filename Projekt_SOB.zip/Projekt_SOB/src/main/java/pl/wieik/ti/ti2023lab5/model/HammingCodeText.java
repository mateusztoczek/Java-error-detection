package pl.wieik.ti.ti2023lab5.model;

public class HammingCodeText {
    HammingResponse table[];

    public HammingResponse[] getTable() {
        return table;
    }

    public void setTable(HammingResponse table[]) {
        this.table = table;
    }
}
